CREATE PROCEDURE country_hos(IN con CHAR(20))
  BEGIN
  Select * from aukcije;
END;
