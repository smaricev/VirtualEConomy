CREATE PROCEDURE deloldprofit()
  delete from profit where date not like (select date from (select date from profit order by date desc limit 1)x);
