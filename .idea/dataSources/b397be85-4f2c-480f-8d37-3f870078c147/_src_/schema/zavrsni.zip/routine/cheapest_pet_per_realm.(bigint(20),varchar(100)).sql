CREATE PROCEDURE cheapest_pet_per_realm(IN con BIGINT, IN petname VARCHAR(100))
  BEGIN
IF petname is null then
	SELECT	
		*
	FROM 
		aukcije a
	JOIN
		( SELECT realm,min(buyout) minbuy 
			FROM aukcije 
			WHERE petSpeciesId = con
			GROUP BY realm ) b
	ON
	a.buyout = b.minbuy and a.realm=b.realm
	JOIN 
	 ( SELECT realm,MAX(date) mdate from aukcije group by realm ) k
	ON k.mdate = a.date and k.realm=a.realm
	WHERE 
		petSpeciesId = con
	ORDER BY 
		buyout;
ELSE
	SELECT	
		*
	FROM 
		aukcije a
	JOIN
		( SELECT realm,min(buyout) minbuy 
			FROM aukcije 
			WHERE petSpeciesId = (select petid from item i where i.name = petname limit 1)
			GROUP BY realm ) b
	ON
	a.buyout = b.minbuy and a.realm=b.realm
	JOIN 
	 ( SELECT realm,MAX(date) mdate from aukcije group by realm ) k
	ON k.mdate = a.date and k.realm=a.realm
	WHERE 
		petSpeciesId = (select petid from item i where  i.name = petname limit 1)
	ORDER BY 
		buyout;
END IF;
END;
