CREATE PROCEDURE allpetids()
  Select 
	petid
FROM
	item i
WHERE
	petid != 0;
